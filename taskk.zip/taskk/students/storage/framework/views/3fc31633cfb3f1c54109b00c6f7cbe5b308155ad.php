  <html>
      <head>
          <title> Students </title>
         
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

</head>
<body>
<div class="container">
  <div class="row">

  <?php if(session('status')): ?>
                <h6 class="alert alert-success"><?php echo e(session('status')); ?></h6>
            <?php endif; ?>

    <div class="col-md-4 col-md-offset-4">
      <h2 style="text-align:center;">Students Details</h2> <hr/> <br/>
   
        <form action="<?php echo e(url('student-register')); ?>" method="POST" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
    <div class="form-group">  
    <label for="usr">First Name:</label>
    <input type="text" class="form-control" id="usr" placeholder="Enter First Name" name="firstname">
    <span class="text-danger"><?php $__errorArgs = ['firstname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
    </div>

    <div class="form-group">  
    <label for="usr">Last Name:</label>
    <input type="text" class="form-control" id="usr" placeholder="Enter Last Name" name="lastname">
    <span class="text-danger"><?php $__errorArgs = ['lastname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>

    </div>



     <div class="form-group">
    <label for="usr">Email:</label>
    <input type="email" class="form-control" id="usr" placeholder="Enter Email" name="email">
    <span class="text-danger"><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
    
     </div>

     <div class="form-group">
    <label for="usr">Password:</label>
    <input type="password" class="form-control" id="usr" placeholder="Enter Password" name="password">
    <span class="text-danger"><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
    
     </div>

     <div class="form-group">
    <label for="usr">Mobile:</label>
    <input type="text" class="form-control" id="usr" placeholder="Enter Mobile" name="mobile">
    <span class="text-danger"><?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
   
     </div>


     <div class="form-group">
    <label for="usr">Pincode:</label>
    <input type="text" class="form-control" id="usr" placeholder="Enter Pincode" name="pincode">
    <span class="text-danger"><?php $__errorArgs = ['pincode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
      
     </div>



     <div class="form-group">
    <label for="usr">Profile Image:</label>
    <input type="file"  name="profileimage" class="form-control">
    <span class="text-danger"><?php $__errorArgs = ['profileimage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
   
     </div>

     <div class="form-group">
    
    <input type="submit" class="btn btn-primary" name="submit" value="Submit"> 
     </div>
     <br>
   

</form>
    </div>
    
    
  </div>
</div>

</body>

  </html><?php /**PATH C:\Users\user\Desktop\taskk\students\resources\views/students.blade.php ENDPATH**/ ?>