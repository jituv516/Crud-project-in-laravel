<!DOCTYPE html>
<html lang="en">
<head>
  <title>Student Details</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <h2>Student  List</h2> <hr/> <br/>
  <table class="table">
    <thead>
      <tr>
      <th>S.no </th> 
        <th>First Name </th>
        <th>Last Name </th>       
        <th>Email</th>
        <th>Password</th>
        <th>Mobile </th>
        <th>Pincode  </th>
        <th>Profile Image </th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
       <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $students): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
     <td><?php echo e($students->id); ?></td>
        <td><?php echo e($students->firstname); ?></td>
        <td><?php echo e($students->lastname); ?></td>
        <td><?php echo e($students->email); ?></td>
        <td><?php echo e($students->password); ?></td>
        <td><?php echo e($students->mobile); ?></td>
        <td><?php echo e($students->pincode); ?></td>
        <td>
        <img src="uploads/students/<?php echo e($students->profileimage); ?>"  width="50" height="50">
        </td>
        <td> 
            <a href="<?php echo e(url('edit/'.$students->id)); ?>" class="btn btn-primary">Edit </a>
            <a href="<?php echo e(url('delete/'.$students->id)); ?>" class="btn btn-danger">Delete </a>
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     
    </tbody>
  </table>
</div>

</body>
</html>
<?php /**PATH C:\Users\user\Desktop\taskk\students\resources\views/student_details.blade.php ENDPATH**/ ?>