<!DOCTYPE html>
<html lang="en">
<head>
  <title>Edit Students</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <h2>Edit Students</h2>
  <form action="<?php echo e(url('update-details/'.$students->id)); ?>" method="post">
  <?php if(Session::has('status')): ?>
        <div class="alert alert-success"> <?php echo e(Session::get('status')); ?></div>
        <?php endif; ?>

    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
   
    <div class="form-group">  
    <label for="usr">First Name:</label>
    <input type="text" class="form-control" id="usr" value="<?php echo e($students->firstname); ?>" placeholder="Enter First Name" name="firstname">
    <span class="text-danger"><?php $__errorArgs = ['firstname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
    </div>

    <div class="form-group">  
    <label for="usr">Last Name:</label>
    <input type="text" class="form-control" id="usr" value="<?php echo e($students->lastname); ?>" placeholder="Enter Last Name" name="lastname">
    <span class="text-danger"><?php $__errorArgs = ['lastname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>

    </div>



     <div class="form-group">
    <label for="usr">Email:</label>
    <input type="email" class="form-control" id="usr" value="<?php echo e($students->email); ?>" placeholder="Enter Email" name="email">
    <span class="text-danger"><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
    
     </div>

     <div class="form-group">
    <label for="usr">Password:</label>
    <input type="password" class="form-control" id="usr" value="<?php echo e($students->password); ?>" placeholder="Enter Password" name="password">
    <span class="text-danger"><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
    
     </div>

     <div class="form-group">
    <label for="usr">Mobile:</label>
    <input type="text" class="form-control" id="usr" value="<?php echo e($students->mobile); ?>" placeholder="Enter Mobile" name="mobile">
    <span class="text-danger"><?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
   
     </div>


     <div class="form-group">
    <label for="usr">Pincode:</label>
    <input type="text" class="form-control" id="usr" value="<?php echo e($students->pincode); ?>" placeholder="Enter Pincode" name="pincode">
    <span class="text-danger"><?php $__errorArgs = ['pincode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
      
     </div>



    

     <div class="form-group mb-3">
                            <label for="">Student Profile Image</label>
                            <input type="file" name="profile_image" class="form-control">
                            <img src="<?php echo e(asset('uploads/students/'.$students->profileimage)); ?>" width="70px" height="70px" alt="Image">
                        </div>

     <div class="form-group">
    
    <input type="submit" class="btn btn-primary" name="submit" value="Update"> 
     </div>
  </form>
</div>

</body>
</html>
<?php /**PATH C:\Users\user\Desktop\taskk\students\resources\views/edit_student.blade.php ENDPATH**/ ?>