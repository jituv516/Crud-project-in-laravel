<!DOCTYPE html>
<html lang="en">
<head>
  <title>Student Details</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <h2>Student  List</h2> <hr/> <br/>
  <table class="table">
    <thead>
      <tr>
      <th>S.no </th> 
        <th>First Name </th>
        <th>Last Name </th>       
        <th>Email</th>
        <th>Password</th>
        <th>Mobile </th>
        <th>Pincode  </th>
        <th>Profile Image </th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
       @foreach($students as $students)
      <tr>
     <td>{{$students->id}}</td>
        <td>{{$students->firstname}}</td>
        <td>{{$students->lastname}}</td>
        <td>{{$students->email}}</td>
        <td>{{$students->password}}</td>
        <td>{{$students->mobile}}</td>
        <td>{{$students->pincode}}</td>
        <td>
        <img src="uploads/students/{{$students->profileimage}}"  width="50" height="50">
        </td>
        <td> 
            <a href="{{url('edit/'.$students->id)}}" class="btn btn-primary">Edit </a>
            <a href="{{url('delete/'.$students->id)}}" class="btn btn-danger">Delete </a>
        </td>
      </tr>
      @endforeach
     
    </tbody>
  </table>
</div>

</body>
</html>
