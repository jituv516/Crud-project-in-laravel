  <html>
      <head>
          <title> Students </title>
         
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

</head>
<body>
<div class="container">
  <div class="row">

  @if (session('status'))
                <h6 class="alert alert-success">{{ session('status') }}</h6>
            @endif

    <div class="col-md-4 col-md-offset-4">
      <h2 style="text-align:center;">Students Details</h2> <hr/> <br/>
   
        <form action="{{ url('student-register') }}" method="POST" enctype="multipart/form-data">
@csrf
    <div class="form-group">  
    <label for="usr">First Name:</label>
    <input type="text" class="form-control" id="usr" placeholder="Enter First Name" name="firstname">
    <span class="text-danger">@error('firstname') {{$message}} @enderror </span>
    </div>

    <div class="form-group">  
    <label for="usr">Last Name:</label>
    <input type="text" class="form-control" id="usr" placeholder="Enter Last Name" name="lastname">
    <span class="text-danger">@error('lastname') {{$message}} @enderror </span>

    </div>



     <div class="form-group">
    <label for="usr">Email:</label>
    <input type="email" class="form-control" id="usr" placeholder="Enter Email" name="email">
    <span class="text-danger">@error('email') {{$message}} @enderror </span>
    
     </div>

     <div class="form-group">
    <label for="usr">Password:</label>
    <input type="password" class="form-control" id="usr" placeholder="Enter Password" name="password">
    <span class="text-danger">@error('password') {{$message}} @enderror </span>
    
     </div>

     <div class="form-group">
    <label for="usr">Mobile:</label>
    <input type="text" class="form-control" id="usr" placeholder="Enter Mobile" name="mobile">
    <span class="text-danger">@error('mobile') {{$message}} @enderror </span>
   
     </div>


     <div class="form-group">
    <label for="usr">Pincode:</label>
    <input type="text" class="form-control" id="usr" placeholder="Enter Pincode" name="pincode">
    <span class="text-danger">@error('pincode') {{$message}} @enderror </span>
      
     </div>



     <div class="form-group">
    <label for="usr">Profile Image:</label>
    <input type="file"  name="profileimage" class="form-control">
    <span class="text-danger">@error('profileimage') {{$message}} @enderror </span>
   
     </div>

     <div class="form-group">
    
    <input type="submit" class="btn btn-primary" name="submit" value="Submit"> 
     </div>
     <br>
   

</form>
    </div>
    
    
  </div>
</div>

</body>

  </html>