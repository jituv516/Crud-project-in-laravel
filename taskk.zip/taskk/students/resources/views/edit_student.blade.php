<!DOCTYPE html>
<html lang="en">
<head>
  <title>Edit Students</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <h2>Edit Students</h2>
  <form action="{{url('update-details/'.$students->id)}}" method="post">
  @if(Session::has('status'))
        <div class="alert alert-success"> {{Session::get('status')}}</div>
        @endif

    @csrf
    @method('PUT')
   
    <div class="form-group">  
    <label for="usr">First Name:</label>
    <input type="text" class="form-control" id="usr" value="{{$students->firstname}}" placeholder="Enter First Name" name="firstname">
    <span class="text-danger">@error('firstname') {{$message}} @enderror </span>
    </div>

    <div class="form-group">  
    <label for="usr">Last Name:</label>
    <input type="text" class="form-control" id="usr" value="{{$students->lastname}}" placeholder="Enter Last Name" name="lastname">
    <span class="text-danger">@error('lastname') {{$message}} @enderror </span>

    </div>



     <div class="form-group">
    <label for="usr">Email:</label>
    <input type="email" class="form-control" id="usr" value="{{$students->email}}" placeholder="Enter Email" name="email">
    <span class="text-danger">@error('email') {{$message}} @enderror </span>
    
     </div>

     <div class="form-group">
    <label for="usr">Password:</label>
    <input type="password" class="form-control" id="usr" value="{{$students->password}}" placeholder="Enter Password" name="password">
    <span class="text-danger">@error('password') {{$message}} @enderror </span>
    
     </div>

     <div class="form-group">
    <label for="usr">Mobile:</label>
    <input type="text" class="form-control" id="usr" value="{{$students->mobile}}" placeholder="Enter Mobile" name="mobile">
    <span class="text-danger">@error('mobile') {{$message}} @enderror </span>
   
     </div>


     <div class="form-group">
    <label for="usr">Pincode:</label>
    <input type="text" class="form-control" id="usr" value="{{$students->pincode}}" placeholder="Enter Pincode" name="pincode">
    <span class="text-danger">@error('pincode') {{$message}} @enderror </span>
      
     </div>



    

     <div class="form-group mb-3">
                            <label for="">Student Profile Image</label>
                            <input type="file" name="profile_image" class="form-control">
                            <img src="{{ asset('uploads/students/'.$students->profileimage) }}" width="70px" height="70px" alt="Image">
                        </div>

     <div class="form-group">
    
    <input type="submit" class="btn btn-primary" name="submit" value="Update"> 
     </div>
  </form>
</div>

</body>
</html>
