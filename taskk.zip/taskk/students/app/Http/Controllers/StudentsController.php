<?php

namespace App\Http\Controllers;
use App\Models\student;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;

class StudentsController extends Controller
{
    //
    public function students()
    {
        return view('students');
    }

    public function store(Request $request)
    {

        $request->validate([
            'firstname'=>'required',
            'lastname'=>'required',
            'password'=>'required|min:5|max:12',
            'email'=>'required|email|unique:students',
            'mobile'=>'required|max:10',
            'pincode'=>'required|max:6'
         
            ]);


        $student = new Student;
        $student->firstname = $request->input('firstname');
        $student->lastname = $request->input('lastname');
        $student->email = $request->input('email');
        $student->password = $request->input('password');
        $student->mobile = $request->input('mobile');
        $student->pincode = $request->input('pincode');

        if($request->hasfile('profileimage')){
            $file = $request->file('profileimage');
          $extension = $file->getClientOriginalExtension();
          $filename = time().'.'.$extension;        
          $file->move('uploads/students/',$filename);
          $student->profileimage = $filename;
        }



        $student->save();
        return redirect()->back()->with('status','Student Added Successfully');
    }


    public function studentsshow(){
        //return "Employee show"; 
        //return view("auth.employeshow");
        $students = student::all();
     return view("student_details",compact("students"));
      }


      public function edit_student($id){
        $students = student::find($id);      
        return view("edit_student",compact("students"));
        }



        public function update(Request $request,$id){
            $students = student::find($id);   
            $students->firstname = $request->input('firstname');
            $students->lastname = $request->input('lastname');
            $students->email = $request->input('email');           
            $students->password = $request->input('password');
            $students->mobile = $request->input('mobile');
            $students->pincode = $request->input('pincode');
    
           


            if($request->hasfile('profile_image'))
            {
                $destination = 'uploads/students/'.$students->profileimage;
                if(File::exists($destination))
                {
                    File::delete($destination);
                }
                $file = $request->file('profile_image');
                $extention = $file->getClientOriginalExtension();
                $filename = time().'.'.$extention;
                $file->move('uploads/students/', $filename);
                $students->profileimage = $filename;
               
            }
    



            $students->update();
          //  return redirect('/student_details')->with('status',"Data updated Successfully");
           // return back()->with('status',"Data updated Successfully");
           return redirect()->back()->with('status',"Data updated Successfully");

          }
          
        

          

      public function remove($id){
        $students = student::find($id);
        $students->delete();
        return redirect('student_details')->with('status',"Data Delete Successfully");
      }
}
