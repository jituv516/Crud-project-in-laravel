<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\StudentsController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('student-register',[StudentsController::class,'students']);
Route::post('student-register', [StudentsController::class, 'store']);

Route::get('/student_details',[StudentsController::class,'studentsshow']);
Route::get('edit/{id}',[StudentsController::class,'edit_student']);
Route::put('update-details/{id}',[StudentsController::class,'update']);
Route::get('delete/{id}',[StudentsController::class,'remove']);